package Request_Response;

/**
 * Deletes ALL data from the database, including user, authToken, persona and event data
 * The request body is empty
 */
public class ClearRequest {

/**
 * No response body included in the HTTP
 */

}
