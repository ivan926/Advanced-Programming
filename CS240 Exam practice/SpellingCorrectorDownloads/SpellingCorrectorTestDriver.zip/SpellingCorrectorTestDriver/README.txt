This is the Test Driver for Spelling Corrector. This driver is provided for those with the knowledge and know-how to enable them to run tests through the terminal and other such activities. If you use this file YOU are responsible for getting it to work, the TA's will provide support for the tests intended to be integrated into your IDE. They cannot provide support for this command line driver.

To get this to work, you will need the jar files included in this zip and the .class files for the classes included in the other test code zip file (the one intended for use with Intellij).

If you are unable to get this to work without help from the TAs, please use the Intellij tests and the provided tutorial instead.
