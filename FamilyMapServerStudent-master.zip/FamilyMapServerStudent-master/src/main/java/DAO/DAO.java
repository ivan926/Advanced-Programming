package DAO;

public class DAO {


    public int clear()throws DataAccessError {
        return 0;
    }
}
